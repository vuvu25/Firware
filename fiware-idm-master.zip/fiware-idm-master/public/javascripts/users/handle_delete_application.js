// class HandleDeleteApplication {
//   constructor() {
//     this.ui = {};
//
//     this.applications_page = $('div#third_party_applications_page');
//
//     //Delete aplication modal
//     this.modal_delete_application = $('div#delete_application_modal');
//     this.button_delete_application = $(
//       'button#delete_application',
//       this.applications_page
//     );
//     this.form_delete_application = $(
//       'form#delete_application_form',
//       this.modal_delete_application
//     );
//   }
// }
