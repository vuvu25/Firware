# イントロダクション

Identity Management のインストールおよび管理ガイド - KeyRock Generic Enabler
へようこそ。このセクションでは、KeyRock の動作中のインスタンスをインストール、
設定、管理する方法について説明します。
