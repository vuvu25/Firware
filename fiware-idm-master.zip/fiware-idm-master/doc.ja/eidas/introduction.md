<a name="introduction"></a>

# イントロダクション

eID (Secure Electronic Identification) は、特に本当の身元を信頼できる
インフラストラクチャに組み込むことが大きな可能性を秘めているスマート・
シティのような新しいアプリケーション分野において、データ保護、
プライバシー、およびオンライン詐欺防止の主要な実現要因の1つです。

eID は、個人の明確な識別を保証し、本当にその資格がある人にサービスを
提供することを可能にします。電子識別、認証および信頼サービス (eIDAS)
規則は、他の加盟国で発行された eIDs を認識して受け入れるための
ソリューションを欧州の加盟国に提供します。

eID メカニズムのための相互運用性ノードの技術仕様およびリファレンス実装
は、Connecting Europe Facility (CEF) プログラムの下の技術
インフラストラクチャのために、2015年11月26日に
[オープンソースとして公開](https://joinup.ec.europa.eu/solution/european-system-recognition-electronic-identities-eidas)
されました。

最終的な目標は、公共および民間のサービスにオンラインでアクセスする
ときに、EU 市民が他の EU 諸国で自国の eID を使用する可能性を提供すること
です。

この GE が提供する FIWARE identity - eIDAS authentication モジュールは、
FIWARE ベースの OAuth2 認証ドメインでの国内 eID を使用して、EU市民の
CEF eID トランスナショナル認証を可能にします。

したがって、FIWARE セキュリティ基準に従って展開されたすべてのサービス
は、eID を使用して、サービス・プロバイダにとって透過的な方法で、
欧州の市民からアクセス可能になります。
