## さらに詳しい情報

KeyRockの詳細については、
[Help & Info Portal](https://fiware-academy.readthedocs.io/en/latest/security/keyrock)
で "Account" を選択し、ステップ・バイ・ステップのビデオを参照してください。

![](https://raw.githubusercontent.com/ging/fiware-idm/master/doc/resources/UserGuide_screencast.png)

<p align="center">図24: KeyRock スクリーンキャスト</p>
