# Introduction

Welcome to the Installation and Administration Guide for the Identity
Management - KeyRock Generic Enabler. This section will cover how to install,
configure and administrate a working instance of KeyRock.
