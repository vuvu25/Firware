## Further information

For further information on KeyRock, please refer to the step-by-step video at

[Help & Info Portal](https://fiware-academy.readthedocs.io/en/latest/security/keyrock)
choosing “Account”.

![](https://raw.githubusercontent.com/ging/fiware-idm/master/doc/resources/UserGuide_screencast.png)

<p align="center">Figure 24: KeyRock Screencast</p>
