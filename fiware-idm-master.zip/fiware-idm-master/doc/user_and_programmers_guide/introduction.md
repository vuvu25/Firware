# Introduction

This document describes the user and programming guide for Identity Management
component. Here you will find the necessary steps for use the IdM portal for
create an account and manage it. You will also learn about role and applications
management.
